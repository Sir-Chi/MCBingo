# Ran by every item detection advancement as player who got advancement

# Get player's team 
$execute as @s[team=blue] run return run function bingo:universal/item_active_check {category:'$(category)', difficulty:'$(difficulty)', name:'$(name)', item:'$(item)', team:'blue', team_name:'itemsBlue', team_color:'blue'}
$execute as @s[team=red] run return run function bingo:universal/item_active_check {category:'$(category)', difficulty:'$(difficulty)', name:'$(name)', item:'$(item)', team:'red', team_name:'itemsRed', team_color:'red'}
$execute as @s[team=green] run return run function bingo:universal/item_active_check {category:'$(category)', difficulty:'$(difficulty)', name:'$(name)', item:'$(item)', team:'green', team_name:'itemsGreen', team_color:'green'}
$execute as @s[team=yellow] run return run function bingo:universal/item_active_check {category:'$(category)', difficulty:'$(difficulty)', name:'$(name)', item:'$(item)', team:'yellow', team_name:'itemsYellow', team_color:'yellow'}
$execute as @s[team=purple] run return run function bingo:universal/item_active_check {category:'$(category)', difficulty:'$(difficulty)', name:'$(name)', item:'$(item)', team:'purple', team_name:'itemsPurple', team_color:'dark_purple'}
$execute as @s[team=pink] run return run function bingo:universal/item_active_check {category:'$(category)', difficulty:'$(difficulty)', name:'$(name)', item:'$(item)', team:'pink', team_name:'itemsPink', team_color:'light_purple'}
$execute as @s[team=cyan] run return run function bingo:universal/item_active_check {category:'$(category)', difficulty:'$(difficulty)', name:'$(name)', item:'$(item)', team:'cyan', team_name:'itemsCyan', team_color:'dark_aqua'}
$execute as @s[team=orange] run return run function bingo:universal/item_active_check {category:'$(category)', difficulty:'$(difficulty)', name:'$(name)', item:'$(item)', team:'orange', team_name:'itemsOrange', team_color:'gold'}